export interface User{
    accountId: string
    nickname: string
    profileUrl: string
    ranking: number
    mscore: number
    tier: string
}